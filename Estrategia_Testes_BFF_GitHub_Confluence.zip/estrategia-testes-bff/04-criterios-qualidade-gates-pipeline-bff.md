# Critérios de Qualidade e Gates do Pipeline — BFF

## Objetivo

Definir evidências e critérios para promoção do BFF, com feedback local antecipado e validações integradas proporcionais ao risco. Os gates devem ser acordados com desenvolvimento, qualidade, segurança e responsáveis pela release.

## Etapas recomendadas

| Etapa | Execução | Condição para avançar |
|---|---|---|
| Merge Request | Compilação, análise estática, unitários, integração local e funcionais críticos | Checks obrigatórios aprovados e revisão concluída |
| Validação do candidato | Regressão funcional local completa e geração do artefato | Cobertura prevista aprovada; artefato identificado |
| Deploy UAT | Implantação do artefato aprovado | Deploy concluído e versão conferida |
| Smoke UAT | Health/readiness e operação mínima crítica | Aplicação pronta para validações |
| Integração UAT | Suíte seletiva com provedores reais | Integrações críticas aprovadas |
| E2E impactado | Jornadas críticas relacionadas à mudança | Resultados de negócio aprovados |
| Avaliação da release | Evidências, defeitos, exploração e riscos residuais | Decisão conforme governança |

A compilação ocorre antes da execução dos testes que dependem dela. A ordem exata e o paralelismo dos jobs dependem do build. Promover o mesmo artefato validado, identificando commit, versão e execução; um rebuild diferente exige rastreabilidade e validação adequada.

## Gate de Merge Request

No GitLab, executar checks locais sem depender de UAT. A suíte deve comprovar riscos críticos da alteração, além da regressão prevista.

Quando o tempo permitir, executar a regressão local completa no MR. Se houver divisão, usar suíte crítica no MR e regressão completa no candidato antes de UAT. Definir orçamento de tempo e cobertura com o time; não usar somente testes novos como evidência de ausência de regressão.

## Gate pré-deploy

Exigir compilação, checks obrigatórios e suítes locais aprovados para a revisão promovida. Registrar evidências, versão do artefato e limitações conhecidas.

Uma aprovação anterior de outro commit não comprova o candidato atual. A política de análise estática e vulnerabilidades deve seguir os critérios de segurança da organização.

## Smoke após deploy

Validar disponibilidade, readiness, versão implantada e uma operação mínima representativa. Um endpoint de health isolado não comprova funcionamento da integração.

Se o smoke falhar, interromper a suíte integrada extensa e investigar deploy, configuração ou disponibilidade. Definir recuperação ou rollback conforme o processo operacional.

## Integração UAT e E2E

Executar integração seletiva após smoke. Comprovar comunicação, identidade, configuração e compatibilidade com provedores reais.

Executar as jornadas E2E impactadas quando suas dependências estiverem operacionais. Mudanças compartilhadas, como segurança ou gateway, podem justificar conjunto maior de jornadas.

Registrar versões dos componentes quando disponíveis, massa, ambiente e identificador da execução. Essas informações ajudam a distinguir falha do produto de mudanças no ambiente.

## Decisão sobre falhas

| Situação | Tratamento esperado |
|---|---|
| Build quebrado ou regressão crítica confirmada | Bloquear promoção e corrigir |
| Integração crítica ou jornada essencial quebrada | Bloquear e investigar com evidências |
| Vulnerabilidade fora da política | Aplicar o gate de segurança vigente |
| Dependência indisponível | Resultado inconclusivo; restaurar ambiente e reexecutar validação necessária |
| Teste instável conhecido | Aplicar processo de quarentena; avaliar risco sem a evidência |
| Problema não crítico conhecido | Decisão documentada por responsável autorizado |

Indisponibilidade externa não é aprovação. Uma exceção deve ter justificativa, impacto, evidência alternativa, aprovador conforme governança e prazo de revisão.

## Política de testes instáveis

1. Preservar o resultado e as evidências da falha inicial.
2. Classificar causa provável: produto, automação, massa ou ambiente.
3. Abrir item com responsável e prazo de correção.
4. Usar quarentena temporária somente quando necessário, tornando visível a perda de cobertura.
5. Definir evidência alternativa para risco crítico enquanto o teste estiver fora do gate.
6. Reincorporar o teste após comprovar estabilidade nas condições de execução relevantes.

Retry automático não deve ocultar falhas. Registrar a aprovação somente após nova tentativa como ocorrência de instabilidade, conforme a classificação do time.

## Diagnóstico por escopo

| Falha | Hipóteses iniciais |
|---|---|
| Unitário | Decisão, mapper, conversão ou asserção |
| Integração local | Client, adapter, filtros, serialização ou configuração do teste |
| Funcional local | Comportamento externo, orquestração ou stub incorreto |
| Smoke UAT | Deploy, versão, configuração ou disponibilidade |
| Integração UAT | Compatibilidade, identidade, conectividade, massa ou erro não coberto localmente |
| E2E | Estado da jornada, interação entre sistemas, regra, massa ou falha de canal |

Estas hipóteses orientam a investigação; não determinam a causa. Uma falha em UAT ainda pode revelar defeito funcional que os testes locais não cobriram.

## Evidências mínimas

Registrar commit/artefato, ambiente, horário, suíte, resultados e links dos relatórios. Em falhas, incluir request/response sanitizados, IDs de correlação e diagnóstico útil. Para E2E do canal, incluir capturas ou vídeo quando relevantes.

## Indicadores

| Indicador | Como observar | Uso |
|---|---|---|
| Aprovação por suíte | Aprovados, falhos, ignorados e inconclusivos separados | Confiança disponível por escopo |
| Tempo de feedback | Duração e fila dos checks | Identificar gargalos |
| Instabilidade | Ocorrências instáveis / execuções elegíveis no período | Saúde da automação |
| Defeitos por ponto de descoberta | Local, UAT, E2E e produção; classificados por causa | Melhorar prevenção |
| Defeitos escapados | Defeitos detectados após promoção para a etapa seguinte | Revisar lacunas de cobertura |
| Tempo de diagnóstico | Falha até identificação da causa | Qualidade das evidências |
| Pendências de automação | Itens em quarentena, idade e risco | Evitar perda permanente de cobertura |

Quantidade de testes e cobertura de linhas são indicadores auxiliares. Não usar taxa global de aprovação para compensar uma jornada crítica falhando. Definir período e denominador das métricas para comparar tendências de forma consistente.

## Definition of Done — Qualidade do BFF

Aplicar conforme o risco e a responsabilidade da alteração:

- [ ] Critérios de aceite e riscos relevantes definidos.
- [ ] Unitários com asserções sobre comportamento implementados.
- [ ] Integração local e funcional local implementadas conforme matriz.
- [ ] Entradas, transformações, autorização e erros relevantes cobertos.
- [ ] Resiliência validada quando implementada e impactada.
- [ ] Status, schema aplicável e conteúdo validados.
- [ ] Regressão local aprovada para o candidato promovido.
- [ ] Artefato e revisão rastreáveis.
- [ ] Deploy e smoke UAT aprovados.
- [ ] Integrações críticas previstas aprovadas.
- [ ] Jornadas E2E impactadas aprovadas.
- [ ] Exploração baseada em risco realizada quando necessária.
- [ ] Evidências disponíveis e dados sensíveis protegidos.
- [ ] Defeitos e riscos residuais documentados, com decisão responsável.
- [ ] Testes instáveis possuem responsável, prazo e cobertura alternativa quando necessária.

## Revisão dos gates

Revisar quando o pipeline ficar lento, surgirem falhas recorrentes ou ocorrerem escapes. Melhorar o escopo e as evidências antes de simplesmente aumentar a suíte integrada.

> O pipeline deve detectar cedo os defeitos comprováveis localmente e exigir evidências específicas para os riscos de integração e de jornada.

## Páginas relacionadas

- [Arquitetura e Estratégia de Testes — BFF](01-arquitetura-estrategia-testes-bff.md)
- [Padrão de Testes Funcionais — BFF](02-padrao-testes-funcionais-bff.md)
- [Matriz de Cobertura — Local x UAT x E2E](03-matriz-cobertura-local-uat-e2e.md)
