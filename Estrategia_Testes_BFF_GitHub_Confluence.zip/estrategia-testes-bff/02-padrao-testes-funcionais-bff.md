# Padrão de Testes Funcionais — BFF

## Objetivo

Padronizar a criação e manutenção da regressão funcional local do BFF. Os testes validam seu comportamento externo com implementação real e downstreams controlados.

## Limite do teste

| Elemento | Padrão |
|---|---|
| BFF | Aplicação real, com suas transformações, filtros e clients relevantes |
| Entrada | HTTP real quando o teste pretende comprovar a interface de rede |
| Downstreams | WireMock ou equivalente, com requests e responses definidos por cenário |
| Estado | Massa e stubs isolados; sem dependência da ordem de execução |
| Saída | Status, schema quando aplicável, conteúdo e interações relevantes |

MockMvc e WebTestClient podem ser usados conforme arquitetura e objetivo. Registrar se a execução usa servidor HTTP real ou binding em memória; os recortes não oferecem a mesma evidência sobre transporte. Não mockar services internos quando a finalidade for validar o comportamento completo do BFF.

## Como criar um teste

1. Identificar o requisito e o risco. Exemplo: uma entrada inválida não pode disparar uma consulta downstream.
2. Selecionar condições e classes de equivalência relevantes. Diferenciar validação do BFF de regra pertencente ao backend.
3. Preparar request, identidade/permissão e responses downstream necessários ao cenário.
4. Configurar stubs com correspondência suficiente para detectar chamadas erradas: método, path, parâmetros, headers e body relevantes.
5. Executar a chamada ao BFF.
6. Validar status, schema aplicável e conteúdo; conferir interações que comprovam requisito.
7. Registrar evidências com dados sensíveis mascarados e remover o estado criado pelo teste.

## Cobertura por responsabilidade

| Responsabilidade | Exemplos de validação |
|---|---|
| Entrada | Obrigatoriedade, formato, tamanho, enum, headers e parâmetros |
| Segurança | Ausência de identidade, permissão insuficiente, recurso de outro usuário |
| Transformação | Campo renomeado, conversão, nulo, valor omitido e formato |
| Agregação | Combinação de respostas, ausência de uma fonte e resultado parcial permitido |
| Orquestração | Chamadas necessárias, parâmetros corretos e interrupção após falha |
| Tradução de erros | Status e mensagem/documento de erro definido pelo contrato do BFF |
| Resiliência | Timeout, retry, fallback e circuit breaker, se implementados |
| Contexto | Propagação de headers, correlation-id e contexto exigido |

Não replicar todas as regras do backend. Validar como o BFF envia dados, interpreta respostas e apresenta resultados ao consumidor.

## Respostas downstream

| Condição | O que comprovar no BFF |
|---|---|
| Sucesso | Transformação, agregação e conteúdo esperado |
| 400, 404 ou 422 | Tradução prevista para erro de entrada, ausência ou regra de negócio |
| 401 ou 403 | Tratamento da falha de autenticação/autorização entre serviços |
| 429 | Política definida para limite de chamadas |
| 500 ou 503 | Erro, fallback ou indisponibilidade conforme requisito |
| Timeout | Resposta dentro do limite e tratamento contratado |
| Payload inválido | Tratamento de falha de deserialização |
| Campo ausente ou nulo | Comportamento conforme contrato e regra de mapeamento |
| Resposta parcial | Resultado parcial ou falha conforme decisão explícita |

Os códigos externos não precisam ser repassados literalmente. A asserção deve seguir o contrato do BFF.

## Padrão de validação do response

- **Status code:** deve corresponder ao resultado contratado.
- **JSON Schema:** validar quando houver corpo JSON; não exigir schema de corpo para 204 ou resposta sem conteúdo. Para outro formato, validar seu contrato equivalente.
- **Conteúdo:** conferir campos, valores e relações relevantes. Schema válido não garante correção semântica.

Evitar comparação integral de respostas com IDs e timestamps dinâmicos. Validar formato, presença e relações necessárias desses campos.

## Padrão de cenário BDD

Nome: `[componente] VERBO /path - resultado esperado`.

Preencher **Objetivo** e **Precondição** antes do cenário. Usar palavras-chave em inglês; o curl fica em `When` e o response em `Then`, delimitados por aspas triplas.

Exemplo ilustrativo, sem representar um contrato existente:

```gherkin
[bff-experiencia-pix] GET /api/v1/destinatarios/{chave} - deve retornar os dados do destinatário

Objetivo: Comprovar a transformação dos dados do backend para o contrato do canal.
Precondição: BFF iniciado, token de teste válido e stub do backend configurado
para responder à consulta da chave com nome e instituição conhecidos.

Scenario: Consultar destinatário por chave
  Given a valid test identity with permission to query recipients
    And the downstream returns the configured recipient data
  When the consumer sends the request
    """
    curl --request GET 'http://localhost:8080/api/v1/destinatarios/chave-exemplo' \
      --header 'Authorization: Bearer TOKEN_DE_TESTE' \
      --header 'Accept: application/json'
    """
  Then the HTTP status code should be 200
    And the response should match the recipient JSON Schema
    And the response content should contain the expected recipient data
    """
    {
      "nome": "Destinatario Exemplo",
      "instituicao": "Instituicao Exemplo"
    }
    """
    And the downstream query should contain the expected key
```

## Organização da automação

Manter os testes no projeto do serviço ou em módulo local que execute o mesmo artefato. Seguir o runner do projeto, sem introduzir dois frameworks de teste por conveniência.

| Responsabilidade | Organização sugerida |
|---|---|
| Cenários | Classes terminadas em `Test`; métodos `dado...quando...entao...` |
| HTTP | Clients e specifications reutilizáveis; RestAssured quando adotado |
| Dados | DTOs, builders e DataFactory |
| Validações | Asserções legíveis e schemas versionados |
| Stubs | Configuração por cenário e exemplos com origem documentada |
| Suporte | Inicialização, isolamento, evidências e limpeza |

JUnit 5 ou TestNG conforme o serviço. Lombok pode reduzir código repetitivo; não é requisito para a estratégia. Com RestAssured, seguir o uso de `ValidatableResponse` e validações Hamcrest quando esse for o padrão do projeto.

## Independência e estabilidade

Cada teste deve executar sozinho, em qualquer ordem e repetidamente. Para paralelismo, isolar portas, IDs, stubs e estado. Não limpar stubs compartilhados durante a execução de outro teste.

Para comportamentos assíncronos, usar espera por condição com limite, por exemplo Awaitility. Evitar sleeps fixos. Em circuit breaker, isolar ou restaurar o estado; em retry, conferir política e quantidade de tentativas apenas quando forem parte do requisito.

Em operações com efeito de negócio, testar proteção contra duplicidade quando existir retry. Não presumir que repetir uma chamada de escrita é seguro.

## Evidências e conclusão

Guardar request, response, stub relevante e diagnóstico de chamadas inesperadas. Mascarar tokens, credenciais e dados pessoais.

A funcionalidade está coberta quando seus riscos relevantes estão ligados a testes, as asserções comprovam os resultados e a suíte passa de forma repetível. Registrar lacunas e limitações dos stubs; não tratar aprovação local como comprovação do provedor real.

## Páginas relacionadas

- [Arquitetura e Estratégia de Testes — BFF](01-arquitetura-estrategia-testes-bff.md)
- [Matriz de Cobertura — Local x UAT x E2E](03-matriz-cobertura-local-uat-e2e.md)
- [Critérios de Qualidade e Gates do Pipeline — BFF](04-criterios-qualidade-gates-pipeline-bff.md)
