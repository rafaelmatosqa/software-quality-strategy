# Matriz de Cobertura — Local x UAT x E2E

## Objetivo

Definir onde comprovar cada risco e justificar a cobertura adicional. A matriz é uma referência de decisão, não uma obrigação de repetir o mesmo cenário em todas as colunas.

**Legenda:** P = cobertura principal; C = complementar quando acrescenta evidência; — = não priorizar para esse risco.

## Matriz de referência

| Risco ou comportamento | Unitário | Integração local | Funcional local | Integração UAT | E2E |
|---|---|---|---|---|---|
| Decisão isolada ou regra do canal | P | — | C | — | — |
| Validação de entrada na API | C | C | P | — | — |
| Transformação ou conversão | P | C | C | — | — |
| Binding, serialização e deserialização | — | P | C | C | — |
| Agregação externa do BFF | C | C | P | C | — |
| Método, path, body e parâmetros downstream | — | P | C | C | — |
| Propagação de headers e contexto | — | P | C | C | — |
| Tratamento de erro downstream | C | C | P | C | — |
| Timeout e resposta inválida | — | C | P | C | — |
| Retry, fallback e circuit breaker | C | P | C | C | — |
| Status, schema e conteúdo do BFF | — | C | P | C | C |
| Autorização implementada no BFF | C | C | P | C | C |
| Comunicação com provedor implantado | — | — | — | P | C |
| Identidade real e autenticação entre serviços | — | C | C | P | C |
| Gateway, endpoints, configuração e certificados | — | — | — | P | C |
| Compatibilidade com payload real do provedor | — | — | — | P | C |
| Resultado completo de uma jornada | — | — | — | C | P |
| Efeito de negócio em persistência ou evento | — | — | — | C | P |

**Aplicabilidade:** persistência e eventos devem ser testados localmente pelos serviços que os implementam. Nesta matriz, o BFF não possui banco ou Kafka próprios. Só incluir consultas a esses recursos na jornada quando necessárias para comprovar seu resultado.

As marcações C de timeout, resiliência e erros em UAT não autorizam provocar indisponibilidade em ambiente compartilhado. Executar apenas se houver controle acordado e risco específico de ambiente que justifique o teste.

## Como decidir

1. Descrever o risco e seu impacto em uma frase.
2. Identificar o componente que controla o comportamento.
3. Escolher o menor recorte capaz de comprovar o risco.
4. Identificar o que permanece sem comprovação: provedor real, configuração, identidade ou jornada.
5. Adicionar UAT ou E2E somente para esse risco residual.
6. Registrar camada, responsável, evidência e frequência de execução.

## Exemplos de decisões

| Situação | Cobertura principal | Cobertura adicional e motivo |
|---|---|---|
| BFF renomeia um campo retornado pelo backend | Unitário do mapper e funcional representativo | UAT se for necessário comprovar o formato real recebido |
| Entrada sem chave não deve consultar backend | Funcional local com ausência de chamada | Nenhuma repetição integrada obrigatória |
| Erro backend deve gerar resposta padronizada | Funcional local com stub de erro | UAT apenas se existir tradução adicional no gateway |
| Token funciona localmente, mas pode ter audience incorreta em UAT | Integração local da política | UAT para a identidade/configuração real |
| Consulta agrega dados de duas APIs | Funcional local para combinações | UAT para compatibilidade das duas dependências |
| Pagamento precisa aparecer como concluído no canal | E2E com limites definidos | Cobertura local e de backend para regras e falhas específicas |
| Repetição de chamada pode duplicar operação | Serviço responsável por idempotência | E2E seletivo se o risco atravessar canal e serviços |

## Sobreposição intencional

O happy path pode existir em três escopos com evidências distintas:

| Escopo | Objetivo | Evidência |
|---|---|---|
| Funcional local | Comprovar adaptação do BFF | Response esperado para respostas controladas |
| Integração UAT | Comprovar compatibilidade e configuração real | Comunicação autenticada com provedores implantados |
| E2E | Comprovar resultado para a jornada | Operação concluída e resultado observável |

Reutilizar helpers não implica executar a mesma suíte integralmente em todos os ambientes. Identificar o propósito de cada teste para evitar multiplicação indiscriminada.

## Registro de cobertura por entrega

Usar a tabela abaixo no refinamento ou no item de trabalho. Informar IDs dos testes ou links para as evidências após implementação.

| Risco/requisito | Impacto | Camada principal | Risco residual integrado | Teste/evidência | Responsável |
|---|---|---|---|---|---|
| Transformação do destinatário | Informação incorreta no canal | Funcional local | Compatibilidade do provedor | A preencher | Desenvolvimento |
| Identidade entre serviços | Operação indisponível ou indevida | Integração UAT | Jornada com perfil autorizado | A preencher | Time |
| Confirmação da operação | Resultado inconsistente ao usuário | E2E | A avaliar | A preencher | QE com apoio do time |

## Critérios para novas inclusões em UAT ou E2E

- Qual risco adicional este teste comprova?
- Por que o ambiente ou a jornada completa são necessários?
- Qual resultado deve ser observado e qual o limite do teste?
- A massa pode ser criada, identificada e limpa de forma confiável?
- A falha pode ser diagnosticada por evidências e correlação?
- O custo de manutenção é proporcional ao impacto?

## Revisão da matriz

Revisar quando houver novo downstream, alteração de segurança, mudança de contrato, incidente ou defeito escapado. Para cada escape, avaliar a menor camada que poderia tê-lo detectado e melhorar essa cobertura.

> Local comprova comportamento. Integração em UAT comprova operação com o ecossistema real. E2E comprova o resultado da jornada dentro dos limites definidos.

## Páginas relacionadas

- [Arquitetura e Estratégia de Testes — BFF](01-arquitetura-estrategia-testes-bff.md)
- [Padrão de Testes Funcionais — BFF](02-padrao-testes-funcionais-bff.md)
- [Critérios de Qualidade e Gates do Pipeline — BFF](04-criterios-qualidade-gates-pipeline-bff.md)
