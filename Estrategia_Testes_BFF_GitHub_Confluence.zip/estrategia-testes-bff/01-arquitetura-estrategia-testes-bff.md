# Arquitetura e Estratégia de Testes — BFF

## Objetivo

Definir como validar BFFs com feedback antecipado, cobertura proporcional ao risco e menor dependência do ambiente integrado. Esta estratégia estabelece o papel dos testes locais, das validações em UAT, das jornadas E2E e dos testes exploratórios.

> Cada risco deve ser coberto na camada mais baixa capaz de comprová-lo com confiança. Validações adicionais precisam acrescentar evidência sobre um risco específico.

## Contexto e limites

O BFF Spring Java atende consumidores web e mobile e consulta APIs de backend. Neste contexto, regras de negócio centrais, persistência e mensageria pertencem principalmente aos backends. O BFF é responsável pelas adaptações e decisões necessárias ao canal.

| Elemento | Responsabilidade considerada |
|---|---|
| Frontend ou canal | Interação do usuário, apresentação e envio de dados |
| BFF | Interface do canal, transformação, agregação, orquestração, segurança e tratamento de falhas, conforme implementação |
| Backend | Regras de negócio, persistência, eventos e integrações do domínio |
| Infraestrutura | Roteamento, conectividade, configuração, certificados e disponibilidade |

Banco e Kafka não são dependências diretas obrigatórias do BFF. Sua validação pertence ao serviço que os utiliza ou à jornada quando o efeito persistido/publicado for necessário para comprovar o resultado de negócio.

## Organização da cobertura

| Escopo | Pergunta | Dependências | Evidência principal |
|---|---|---|---|
| Unitário | A unidade executa sua decisão corretamente? | Dublês de objetos quando necessários | Resultado e ramificações relevantes |
| Integração local | Os componentes e interfaces técnicas selecionados cooperam? | Componentes reais e dependências controladas | Configuração, serialização, clients, adapters e filtros |
| Funcional local | A interface do BFF apresenta o comportamento esperado? | BFF real; downstreams controlados | Request, response e interações externas relevantes |
| Integração em UAT | O artefato implantado opera com suas dependências reais? | Serviços e infraestrutura de UAT | Compatibilidade, segurança, configuração e comunicação |
| E2E | A jornada entrega o resultado de negócio esperado? | Componentes reais dentro dos limites definidos | Resultado observável da jornada |
| Exploratório | Há riscos ou comportamentos ainda não cobertos? | Ambiente adequado à hipótese | Descobertas, evidências e novos riscos |

“Local” também inclui execução isolada no pipeline. UAT é um ambiente, não um nível de teste. E2E é um escopo e pode executar em UAT. Testes exploratórios podem ocorrer antes ou depois do deploy.

## Testes unitários

Validar decisões e transformações isoladas: mapeamentos, conversões, filtros, valores nulos, regras do canal e exceções internas. Priorizar condições que alteram o comportamento. Cobertura de linhas ajuda a localizar lacunas, mas não comprova a qualidade das asserções.

Os testes devem ser rápidos, determinísticos e independentes de rede ou UAT.

## Integração local

Validar recortes técnicos com componentes reais: binding do controller, filtros de segurança, configuração de clients, serialização/deserialização e construção de chamadas HTTP.

Definir explicitamente o recorte. Um teste do client com um servidor stub, por exemplo, comprova método, path, headers, query parameters e payload enviados, além da interpretação da resposta. Não comprova compatibilidade com a versão implantada do provedor.

## Funcional local

Executar o BFF real pela interface definida no projeto, com respostas downstream controladas. Essa camada concentra a regressão do comportamento externo do BFF.

Considerar happy paths, entradas inválidas, autorização, transformação, agregação, tradução de erros, respostas parciais e resiliência implementada. Simular timeout, erro HTTP e resposta inválida sem alterar dependências compartilhadas.

Validar status, formato/schema quando aplicável e conteúdo. Verificar chamadas downstream quando elas comprovarem requisito: propagação de contexto, ausência de chamada em uma entrada inválida ou proteção contra repetição indevida.

## Integração em UAT

Após o deploy e o smoke, comprovar os riscos que dependem do ambiente real: comunicação, compatibilidade de payload, autenticação entre serviços, roteamento, configurações e certificados. Priorizar operações críticas e combinações de integrações distintas.

Não reproduzir todas as variações locais. Um fluxo pode existir em ambas as suítes quando local valida transformação e UAT valida compatibilidade com o provedor implantado.

Logs e traces devem apoiar diagnóstico e correlação. Evitar depender de mensagens de log específicas para provar um resultado funcional, salvo quando o próprio registro for requisito de auditoria.

## E2E

Definir para cada jornada seu início, fim, componentes abrangidos e resultado de negócio. Uma jornada do canal pode iniciar na interface e terminar na confirmação da operação. Uma jornada de backend pode iniciar por API e terminar no efeito de negócio, sem interface gráfica.

Selecionar jornadas por impacto financeiro, segurança, criticidade e integrações envolvidas. Além de sucesso, considerar falhas críticas como duplicidade, confirmação inconsistente ou operação indevida.

Evitar consultar todas as tabelas e todos os tópicos atravessados. Validar os efeitos necessários para comprovar a jornada, usando identificadores de correlação e espera limitada para processamento assíncrono.

## Testes exploratórios

Criar uma missão com risco, escopo, duração e evidências esperadas. Exemplo: “Explorar a apresentação de falha ou resultado parcial quando uma consulta de dados do destinatário não estiver disponível”.

Durante a sessão, registrar variações testadas, comportamento observado e descobertas. Transformar riscos recorrentes em cobertura automatizada na camada adequada. No canal web, incluir usabilidade, responsividade e acessibilidade nos aspectos impactados.

## Responsabilidades

| Atividade | Desenvolvedores | QEs | Liderança técnica e produto |
|---|---|---|---|
| Análise de riscos e critérios de aceite | Contribuem com arquitetura e comportamento | Facilitam exemplos, riscos e testabilidade | Acordam impacto e critérios |
| Unitário, integração e funcional local | Implementam, executam e mantêm | Apoiam desenho e revisam lacunas por risco | Garantem tempo e padrões |
| Integração em UAT e smoke | Mantêm checks técnicos, apoiam diagnóstico | Definem cobertura seletiva com o time | Acordam gates e responsáveis |
| E2E e exploratório | Apoiam massa, observabilidade e diagnóstico | Automatizam jornadas e conduzem exploração | Priorizam jornadas e riscos |
| Falhas e riscos residuais | Investigam e corrigem | Avaliam cobertura e evidências | Decidem exceções conforme governança |

## Evolução sem broker de contratos

A estratégia atual não depende de Pact ou de um broker. Manter os stubs alinhados às especificações disponíveis, registrar a origem dos exemplos e validar seletivamente a compatibilidade real em UAT.

Stubs e JSON Schema isolados não substituem a verificação do provedor. A adoção de contratos verificáveis entre consumidores e provedores pode ser avaliada como evolução, conforme viabilidade técnica e organizacional.

## Resultados esperados e acompanhamento

Buscar redução de defeitos funcionais descobertos apenas em UAT, menor tempo de diagnóstico, menos bloqueios por ambiente e E2E sustentável. Acompanhar tendências e causas; quantidades fixas de testes não devem ser metas universais.

## Páginas relacionadas

- [Padrão de Testes Funcionais — BFF](02-padrao-testes-funcionais-bff.md)
- [Matriz de Cobertura — Local x UAT x E2E](03-matriz-cobertura-local-uat-e2e.md)
- [Critérios de Qualidade e Gates do Pipeline — BFF](04-criterios-qualidade-gates-pipeline-bff.md)
