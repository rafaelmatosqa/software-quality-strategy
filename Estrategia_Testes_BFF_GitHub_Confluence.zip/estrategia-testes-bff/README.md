# Estratégia de Testes — BFF

Documentação para versionar no GitHub e publicar como quatro páginas no Confluence.

**Status:** proposta de referência; gates e responsáveis devem ser acordados com o time.

## Páginas

| Ordem | Arquivo | Organização no Confluence |
|---|---|---|
| 1 | [Arquitetura e Estratégia de Testes — BFF](01-arquitetura-estrategia-testes-bff.md) | Página principal |
| 2 | [Padrão de Testes Funcionais — BFF](02-padrao-testes-funcionais-bff.md) | Filha da página principal |
| 3 | [Matriz de Cobertura — Local x UAT x E2E](03-matriz-cobertura-local-uat-e2e.md) | Filha da página principal |
| 4 | [Critérios de Qualidade e Gates do Pipeline — BFF](04-criterios-qualidade-gates-pipeline-bff.md) | Filha da página principal |

## Como usar

1. Extraia o ZIP e adicione a pasta `estrategia-testes-bff` ao seu repositório, por exemplo em `docs/`.
2. No GitHub, abra um arquivo `.md` e visualize seu conteúdo renderizado, na aba **Preview**, quando disponível.
3. Copie o conteúdo renderizado da página, começando em **Objetivo**, pois o título deve ser preenchido no campo de título do Confluence. Evite copiar pela visualização Raw: ela contém a sintaxe Markdown.
4. Crie a página principal no Confluence e cole normalmente no corpo do editor, preservando formatação. Confira títulos, tabelas, listas e blocos de código antes de publicar. O resultado da colagem pode variar conforme navegador e editor.
5. Crie as outras três páginas como filhas da principal e repita o procedimento.
6. No Confluence, substitua os links relativos de “Páginas relacionadas” por links para as páginas criadas. Esses links relativos funcionam no GitHub; a colagem não cria automaticamente a hierarquia nem converte os destinos.
7. Registre o responsável, a data da revisão e o endereço do arquivo fonte no GitHub em cada página.

Para a transferência inicial, prefira um navegador no computador. Se a tabela não preservar sua estrutura, recrie uma tabela no Confluence com as mesmas colunas e copie os valores. Se um exemplo perder a formatação, use um bloco de código.

## Convenções de edição

- O GitHub é a fonte versionada desta documentação. Atualize os arquivos e replique a revisão nas páginas correspondentes do Confluence.
- Títulos, tabelas, listas e citações usam Markdown simples. A leitura não depende de plugins Mermaid ou de diagramas em texto.
- Os exemplos são ilustrativos e devem ser adaptados aos contratos e às políticas do serviço.
- UAT é um ambiente; E2E é um escopo de teste. Um E2E pode executar em UAT.
- Não existe sincronização automática neste pacote. Mudanças no GitHub precisam ser republicadas no Confluence.

## Labels sugeridas

`bff`, `quality-engineering`, `test-strategy`, `test-automation`, `api-testing`, `uat`, `e2e`, `software-quality`.

## Resumo da estratégia

A maior cobertura do comportamento do BFF ocorre em testes locais com dependências controladas. Em UAT, os testes selecionados comprovam compatibilidade e operação com dependências reais. E2E valida resultados de jornadas críticas. Desenvolvedores implementam e mantêm testes unitários, de integração e funcionais locais; QEs orientam a cobertura por risco, automatizam jornadas E2E e conduzem exploração. A qualidade e a decisão sobre riscos são responsabilidades compartilhadas.
