# Maestro + Zephyr Scale Cloud v2

Projeto base para execução local e GitLab CI em UAT. Flows em YAML e integração em Python 3.11+. O publisher usa Bearer token do Zephyr, não token Jira.

## Limitação de evidências

A API pública Cloud v2 não oferece endpoint documentado para upload de attachments em Test Execution. Este projeto **não anexa arquivos binários ao Zephyr**: publica o resultado e links das evidências no comentário da execução. No GitLab os arquivos ficam nos artifacts do job; localmente configure `EVIDENCE_BASE_URL` apontando para um servidor que contenha `build/`. O projeto não faz upload para esse servidor.

O comentário usa HTML com links; confirme a renderização na sua instância. Upload direto na aba de anexos exige um recurso suportado pelo fornecedor ou operação manual na interface. Não usamos endpoints privados ou Server/DC.

| Resultado | Evidências selecionadas |
|---|---|
| PASS | Vídeos |
| FAIL | Vídeos, screenshots e ZIP dos logs/commands/hierarquia disponíveis |
| SKIP | Sem evidências; status configurável |
| Erro de infraestrutura sem JUnit válido | Não cria resultado funcional; job falha |

Maestro não produz o trace.zip do Playwright. `diagnostico-maestro.zip` é um pacote de diagnóstico do Maestro. A falta de evidências gera aviso, preservando o status. Encerramento abrupto do processo/device pode impedir a finalização do vídeo.

## Preparar

1. Instale Python 3.11+, Maestro CLI com suporte a `properties`, `onFlowComplete` e `--test-output-dir`, e as ferramentas Android/iOS.
2. Inicie um emulador Android ou simulador iOS (macOS), ou conecte um dispositivo suportado, com o aplicativo instalado.
3. Crie um ambiente Python:

```bash
python3 -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

4. Copie `config/local.properties.example` para `config/local.properties`.
5. Ajuste APP_ID, chaves PIX-T123/PIX-R456, seletores e o nome do flow.
6. Inclua novos flows em `config/suite.json`. Subflows de login podem ser chamados com `runFlow`, sem entrar nessa lista como casos independentes.

## Executar localmente

```bash
python scripts/integracao.py run
```

Com `ZEPHYR_ENABLED=false`, executa e coleta evidências sem enviar resultados. Para publicar, configure token, projeto, ciclo existente e `ZEPHYR_ENABLED=true`. Cada variável de ambiente sobrescreve o arquivo local, inclusive se estiver vazia. Valores do arquivo são literais: sem aspas, expansão de variáveis ou comentário no final da linha.

Use um ciclo previamente criado no Zephyr; criação de ciclo automática não faz parte desta base. Os casos precisam existir e os nomes de status devem corresponder aos configurados no projeto (Pass/Fail/Not Executed são defaults). Ajuste `ZEPHYR_STATUS_PASS`, `ZEPHYR_STATUS_FAIL` e `ZEPHYR_STATUS_SKIP`.

## Conferir e repetir publicação

O comando run imprime a localização de `results.json`. Substitua `<run-id>` pelo identificador impresso:

```bash
python scripts/integracao.py publish --manifest build/<run-id>/results.json --dry-run
python scripts/integracao.py publish --manifest build/<run-id>/results.json
```

Dry-run mostra o payload, sem token e sem chamadas HTTP. Não execute em logs públicos se nomes/erros/evidências contiverem informações internas.

`publication.json` guarda resultados confirmados para não reenviar na retomada do mesmo manifest/ciclo. Não há garantia exatamente uma vez: se ocorrer timeout após a criação remota ou falhar a gravação do ledger, confira no Zephyr antes de repetir. Não execute dois publishers concorrentes sobre o mesmo manifest. Novo run gera nova publicação/histórico; esta base faz POST de execução, não busca e atualiza uma execução preexistente por chave. Se o ciclo já tiver os casos pré-alocados, valide o comportamento de histórico/linhas da sua instância em um ciclo de POC antes de adotar em produção.

Códigos de saída: 0 sucesso; 1 falha de teste/infraestrutura; 2 configuração/publicação. Falha de publicação não transforma FAIL em PASS, e run mantém falha dos testes.

## GitLab CI

O `.gitlab-ci.yml` usa runner **shell** dedicado com tag `maestro`, Python, Maestro e dispositivo pronto. Não provisiona emulador nem instala o aplicativo. `resource_group` serializa os jobs deste projeto; runner/dispositivo compartilhado entre projetos precisa de isolamento adicional.

Cadastre em Settings > CI/CD > Variables:

- `ZEPHYR_TOKEN`: masked; protected se o job roda em branches protegidas.
- `ZEPHYR_TEST_CYCLE_KEY`: ciclo existente ou variável manual do pipeline.
- `APP_ID`: identificador do aplicativo.
- `MAESTRO_DEVICE`: opcional, identificador do dispositivo.
- Ajuste `ZEPHYR_PROJECT_KEY` e nomes dos status quando necessário.

O arquivo local não é necessário no CI. O publisher cria URLs com `CI_PROJECT_URL` e `CI_JOB_ID`, apontando para artifacts do próprio job. Eles estarão disponíveis após upload ao final do job. Os links exigem acesso ao GitLab se o projeto for privado; não há credenciais embutidas. Expiram com os artifacts (30 dias no exemplo). Para retenção durável, hospede as evidências em armazenamento corporativo e configure `EVIDENCE_BASE_URL` com a raiz correspondente antes da publicação.

Android e iOS: execute em jobs/ciclos separados e devices adequados. Não rode duas execuções do mesmo caso em um único manifest. O token Zephyr nunca é passado ao Maestro na linha de comando.

## Estrutura e correlação

- `flows/pix/`: cenários e `properties.testCaseKey`.
- `config/suite.json`: lista explícita de flows independentes.
- `scripts/integracao.py`: configuração, execução, parser, seleção de evidências e REST.
- `build/<run-id>/<testCaseKey>/`: JUnit, console e artifacts de um único flow.
- `build/<run-id>/results.json`: manifest normalizado.
- `build/<run-id>/publication.json`: confirmações de publicação.

Um comando Maestro por flow evita adivinhar a relação entre o nome do arquivo de artefato e o testcase. A chave do XML é verificada contra o YAML. Versões antigas que não exportam a property usam a chave do YAML como fallback. Consulte `maestro --version` e `maestro test --help`; fixe no runner a versão validada na sua POC. O vídeo inicia em onFlowStart e finaliza em onFlowComplete tanto em PASS quanto em FAIL. Falha no hook pode falhar o flow conforme o contrato do Maestro.

## Validação

```bash
python -m unittest discover -s tests -v
```

Testes cobrem JUnit PASS/FAIL/SKIP, duração em milissegundos, divergência de chave, isolamento/seleção de evidências, precedência de configuração, payload e retomada. A publicação é testada com cliente simulado. Execução real no app, gravação de vídeo em dispositivo e chamada autenticada ao Zephyr precisam ser validadas no seu ambiente.

## Referências

- [Maestro: reports, properties e artifacts](https://docs.maestro.dev/maestro-flows/workspace-management/test-reports-and-artifacts)
- [Maestro: hooks](https://docs.maestro.dev/maestro-flows/flow-control-and-logic/hooks)
- [Maestro: startRecording](https://docs.maestro.dev/reference/commands-available/startrecording)
- [Zephyr Scale Cloud v2](https://support.smartbear.com/zephyr-scale-cloud/api-docs/)
- [Lacuna de attachments reportada no repositório SmartBear](https://github.com/SmartBear/smartbear-mcp/issues/456)

Documentação consultada em 06/10/2026. A página da API é dinâmica e sua especificação não pôde ser extraída neste ambiente; o payload base usa o contrato público conhecido. Não há alegação de validação autenticada. A limitação de attachments também foi relatada no repositório do fornecedor; confirme mudanças futuras na API oficial.
