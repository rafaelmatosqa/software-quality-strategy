"""Maestro local -> JUnit -> Zephyr Scale Cloud v2. Python 3.11+."""
import argparse
import html
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET
from urllib.request import Request, urlopen
from urllib.parse import quote, urlparse
from urllib.error import HTTPError, URLError
import zipfile
import yaml

ROOT = Path(__file__).resolve().parents[1]


def configuracao(path=None):
    values = {}
    path = Path(path or ROOT / 'config/local.properties')
    if path.exists():
        for line in path.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#'):
                key, sep, value = line.partition('=')
                if not sep:
                    raise ValueError('Linha inválida no arquivo de configuração')
                values[key.strip()] = value.strip()
    values.update(os.environ)
    return values


def chave_flow(path):
    header = yaml.safe_load(path.read_text(encoding='utf-8').split('\n---', 1)[0])
    key = str((header.get('properties') or {}).get('testCaseKey', ''))
    if not re.fullmatch(r'[A-Z][A-Z0-9_]*-T\d+', key):
        raise ValueError(f'{path.name}: properties.testCaseKey inválido/ausente')
    return key


def ler_junit(path, expected):
    root = ET.parse(path).getroot()
    cases = [root] if root.tag == 'testcase' else list(root.iter('testcase'))
    if len(cases) != 1:
        raise ValueError('Cada flow deve produzir exatamente um testcase JUnit')
    case = cases[0]
    props = {p.get('name'): p.get('value', p.text or '') for p in case.findall('./properties/property')}
    # Compatibilidade com versões que emitem property diretamente sob testcase.
    props.update({p.get('name'): p.get('value', p.text or '') for p in case.findall('./property')})
    if props.get('testCaseKey', expected) != expected:
        raise ValueError('testCaseKey do JUnit diverge do YAML')
    error = case.find('failure')
    if error is None:
        error = case.find('error')
    attr = case.get('status', '').upper()
    if error is not None or attr in {'FAILURE', 'FAILED', 'FAIL', 'ERROR'}:
        status = 'FAIL'
    elif case.find('skipped') is not None or attr in {'SKIPPED', 'SKIP', 'DISABLED', 'ABORTED'}:
        status = 'SKIP'
    elif attr and attr not in {'SUCCESS', 'PASSED', 'PASS', 'SUCCESSFUL'}:
        raise ValueError(f'Status JUnit desconhecido: {attr}')
    else:
        status = 'PASS'
    return {'key': expected, 'name': case.get('name', expected), 'status': status,
            'durationMs': round(float(case.get('time', '0')) * 1000),
            'error': '' if error is None else ((error.get('message') or '') + '\n' + (error.text or '')).strip()}


def evidencias(folder, status):
    # Cada chamada Maestro é isolada em uma pasta única; nunca busca artefatos de outro flow.
    files = sorted(p for p in folder.rglob('*') if p.is_file())
    videos = [p for p in files if p.suffix.lower() in {'.mp4', '.webm', '.mov'}]
    warnings = []
    if status == 'SKIP':
        return [], warnings
    if not videos:
        warnings.append('Vídeo ausente; resultado preservado')
    selected = list(videos)
    if status == 'FAIL':
        shots = [p for p in files if p.suffix.lower() in {'.png', '.jpg', '.jpeg'}]
        selected += shots
        if not shots:
            warnings.append('Screenshot ausente; resultado preservado')
        diagnostics = [p for p in files if p.suffix.lower() in {'.json', '.log', '.txt'}]
        if diagnostics:
            archive = folder / 'diagnostico-maestro.zip'
            with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
                for p in diagnostics:
                    z.write(p, p.relative_to(folder))
            selected.append(archive)
    return [p.relative_to(ROOT).as_posix() for p in selected], warnings


def executar(config, suite, run_id=None):
    run_id = run_id or uuid.uuid4().hex
    if not re.fullmatch(r'[A-Za-z0-9_-]+', run_id):
        raise ValueError('run-id inválido')
    run = ROOT / 'build' / run_id
    run.mkdir(parents=True, exist_ok=False)
    flows = json.loads(Path(suite).read_text(encoding='utf-8'))['flows']
    if not flows:
        raise ValueError('Suite vazia')
    paths = [(ROOT / f).resolve() for f in flows]
    for p in paths:
        p.relative_to(ROOT)
    keys = [chave_flow(p) for p in paths]
    if len(keys) != len(set(keys)):
        raise ValueError('testCaseKey duplicado na suite; separe plataformas em execuções distintas')
    results, failed = [], False
    for flow, key in zip(paths, keys):
        folder = run / key
        folder.mkdir()
        report = folder / 'junit.xml'
        cmd = [config.get('MAESTRO_BIN', 'maestro')]
        if config.get('MAESTRO_DEVICE'):
            cmd += ['--device', config['MAESTRO_DEVICE']]
        cmd += ['test', '--format', 'junit', '--output', str(report),
                '--test-output-dir', str(folder / 'artifacts'),
                '--debug-output', str(folder / 'debug'), '-e',
                'APP_ID=' + config.get('APP_ID', 'br.com.seuapp'), str(flow)]
        try:
            with (folder / 'console.log').open('w', encoding='utf-8') as out:
                code = subprocess.run(cmd, cwd=ROOT, stdout=out, stderr=subprocess.STDOUT).returncode
            item = ler_junit(report, key)
            if code != 0 and item['status'] == 'PASS':
                raise ValueError('Maestro retornou erro mas JUnit indica PASS')
            artifacts, warnings = evidencias(folder, item['status'])
            item.update(evidence=artifacts, warnings=warnings, publishable=True)
            failed |= code != 0 or item['status'] == 'FAIL'
        except (OSError, ValueError, ET.ParseError) as exc:
            # Falha de infraestrutura não vira resultado funcional inventado.
            item = {'key': key, 'status': 'INFRA_ERROR', 'publishable': False,
                    'error': str(exc), 'evidence': [], 'warnings': []}
            failed = True
        results.append(item)
    manifest = run / 'results.json'
    manifest.write_text(json.dumps({'runId': run_id, 'results': results}, indent=2, ensure_ascii=False), encoding='utf-8')
    print('Resultados:', manifest.relative_to(ROOT))
    return manifest, failed


def api(config, method, route, payload):
    base = config.get('ZEPHYR_BASE_URL', 'https://api.zephyrscale.smartbear.com/v2').rstrip('/')
    if urlparse(base).scheme != 'https':
        raise ValueError('ZEPHYR_BASE_URL deve usar HTTPS')
    req = Request(base + route, data=json.dumps(payload).encode(), method=method,
                  headers={'Authorization': 'Bearer ' + config['ZEPHYR_TOKEN'], 'Content-Type': 'application/json', 'Accept': 'application/json'})
    try:
        with urlopen(req, timeout=60) as response:
            content = response.read()
            return json.loads(content) if content else {}
    except HTTPError as exc:
        # Não imprime corpo/headers potencialmente sensíveis.
        raise RuntimeError(f'Zephyr HTTP {exc.code} em {method} {route}') from None
    except URLError:
        raise RuntimeError('Falha de conexão Zephyr; verificar antes de repetir POST (resultado remoto pode existir)') from None


def publicar(config, manifest, dry_run=False, requester=api):
    if not dry_run and config.get('ZEPHYR_ENABLED', 'false').lower() != 'true':
        print('Publicação desabilitada (ZEPHYR_ENABLED=false)')
        return False
    required = ['ZEPHYR_PROJECT_KEY', 'ZEPHYR_TEST_CYCLE_KEY'] + ([] if dry_run else ['ZEPHYR_TOKEN'])
    for key in required:
        if not config.get(key):
            raise ValueError(key + ' não configurada')
    project, cycle = config['ZEPHYR_PROJECT_KEY'], config['ZEPHYR_TEST_CYCLE_KEY']
    if not re.fullmatch(re.escape(project) + r'-R\d+', cycle):
        raise ValueError('Ciclo inválido para o projeto')
    data = json.loads(Path(manifest).read_text(encoding='utf-8'))
    ledger_path = Path(manifest).with_name('publication.json')
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else {}
    base = config.get('EVIDENCE_BASE_URL', '').rstrip('/')
    if not base and config.get('CI_PROJECT_URL') and config.get('CI_JOB_ID'):
        base = config['CI_PROJECT_URL'].rstrip('/') + '/-/jobs/' + config['CI_JOB_ID'] + '/artifacts/raw'
    failures = False
    for item in data['results']:
        if not item['publishable']:
            failures = True
            continue
        key = item['key']
        if not re.fullmatch(re.escape(project) + r'-T\d+', key):
            raise ValueError('Caso pertence a outro projeto: ' + key)
        identity = cycle + ':' + key
        if ledger.get(identity):
            print('Já publicado:', identity)
            continue
        lines = [html.escape(item['name']), 'Maestro: ' + item['status'], 'Run: ' + html.escape(data['runId'])]
        if item.get('error'):
            lines.append('<pre>' + html.escape(item['error'][:4000]) + '</pre>')
        for p in item['evidence']:
            local = (ROOT / p).resolve()
            local.relative_to(ROOT)
            if not local.is_file():
                lines.append('Evidência ausente: ' + html.escape(p))
            elif base:
                url = base + '/' + quote(p, safe='/')
                if urlparse(url).scheme not in {'https', 'http'}:
                    raise ValueError('URL de evidência inválida')
                lines.append('<a href="' + html.escape(url, quote=True) + '">' + html.escape(Path(p).name) + '</a>')
            else:
                lines.append('Arquivo local (sem URL): ' + html.escape(p))
        lines += [html.escape(w) for w in item['warnings']]
        if not base and item['evidence']:
            print('Aviso: evidências locais sem URL; não serão acessíveis pelo Zephyr')
        payload = {'projectKey': project, 'testCaseKey': key, 'testCycleKey': cycle,
                   'statusName': config.get('ZEPHYR_STATUS_' + item['status'], {'PASS':'Pass','FAIL':'Fail','SKIP':'Not Executed'}[item['status']]),
                   'executionTime': item['durationMs'], 'comment': '<br>'.join(lines)}
        if config.get('ZEPHYR_ENVIRONMENT_NAME'):
            payload['environmentName'] = config['ZEPHYR_ENVIRONMENT_NAME']
        if dry_run:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
            continue
        try:
            result = requester(config, 'POST', '/testexecutions', payload)
            ledger[identity] = {'response': result, 'runId': data['runId']}
            temp = ledger_path.with_suffix('.tmp')
            temp.write_text(json.dumps(ledger, indent=2), encoding='utf-8')
            temp.replace(ledger_path)
            print('Publicado:', identity)
        except RuntimeError as exc:
            print(str(exc), file=sys.stderr)
            failures = True
    return failures


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['run', 'publish'])
    parser.add_argument('--config')
    parser.add_argument('--suite', default=str(ROOT / 'config/suite.json'))
    parser.add_argument('--manifest')
    parser.add_argument('--run-id')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    config = configuracao(args.config)
    try:
        if args.action == 'run':
            if args.dry_run:
                parser.error('--dry-run aplica-se apenas a publish')
            manifest, failed = executar(config, args.suite, args.run_id)
            publish_failed = publicar(config, manifest)
            return 1 if failed else (2 if publish_failed else 0)
        if not args.manifest:
            parser.error('publish exige --manifest')
        return 2 if publicar(config, args.manifest, args.dry_run) else 0
    except (ValueError, OSError, KeyError) as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
