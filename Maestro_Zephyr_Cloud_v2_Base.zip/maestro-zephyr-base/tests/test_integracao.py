import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('integracao', Path(__file__).parents[1] / 'scripts/integracao.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class IntegracaoTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.old_root = m.ROOT
        m.ROOT = self.root

    def tearDown(self):
        m.ROOT = self.old_root
        self.temp.cleanup()

    def junit(self, body='', status='SUCCESS', key='PIX-T123'):
        path = self.root / 'junit.xml'
        path.write_text(f'<testsuite><testcase name="Pix" time="1.25" status="{status}"><properties><property name="testCaseKey" value="{key}"/></properties>{body}</testcase></testsuite>')
        return path

    def test_junit_status_duracao_correlacao(self):
        self.assertEqual(m.ler_junit(self.junit(), 'PIX-T123')['durationMs'], 1250)
        self.assertEqual(m.ler_junit(self.junit('<failure message="Erro"/>'), 'PIX-T123')['status'], 'FAIL')
        self.assertEqual(m.ler_junit(self.junit('<skipped/>'), 'PIX-T123')['status'], 'SKIP')
        with self.assertRaises(ValueError):
            m.ler_junit(self.junit(key='PIX-T999'), 'PIX-T123')
        with self.assertRaises(ValueError):
            m.ler_junit(self.junit(status='UNKNOWN'), 'PIX-T123')

    def test_politica_evidencias_isolamento(self):
        folder = self.root / 'build/run/PIX-T123'
        folder.mkdir(parents=True)
        for name in ['video.mp4', 'falha.png', 'commands.json']:
            (folder / name).write_text('fixture')
        other = self.root / 'build/run/PIX-T999'
        other.mkdir()
        (other / 'outro.mp4').write_text('fixture')
        passed, _ = m.evidencias(folder, 'PASS')
        self.assertEqual(len(passed), 1)
        failed, _ = m.evidencias(folder, 'FAIL')
        self.assertEqual(len(failed), 3)
        self.assertTrue(any(p.endswith('diagnostico-maestro.zip') for p in failed))
        self.assertFalse(any('PIX-T999' in p for p in failed))

    def test_precedencia_ambiente(self):
        props = self.root / 'local.properties'
        props.write_text('ZEPHYR_TOKEN=arquivo\n')
        with patch.dict(os.environ, {'ZEPHYR_TOKEN': 'ambiente'}):
            self.assertEqual(m.configuracao(props)['ZEPHYR_TOKEN'], 'ambiente')

    def test_publicacao_payload_retomada(self):
        video = self.root / 'build/run/PIX-T123/video.mp4'
        video.parent.mkdir(parents=True)
        video.write_text('fixture')
        manifest = self.root / 'results.json'
        item = m.ler_junit(self.junit(), 'PIX-T123')
        item.update(publishable=True, evidence=['build/run/PIX-T123/video.mp4'], warnings=[])
        manifest.write_text(json.dumps({'runId': 'run', 'results': [item]}))
        config = {'ZEPHYR_ENABLED': 'true', 'ZEPHYR_PROJECT_KEY': 'PIX', 'ZEPHYR_TEST_CYCLE_KEY': 'PIX-R456',
                  'ZEPHYR_TOKEN': 'dummy', 'CI_PROJECT_URL': 'https://gitlab.example/pix', 'CI_JOB_ID': '123'}
        calls = []
        def fake(config, method, route, payload):
            calls.append((method, route, payload))
            return {'id': 123}
        self.assertFalse(m.publicar(config, manifest, requester=fake))
        self.assertFalse(m.publicar(config, manifest, requester=fake))
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][1], '/testexecutions')
        self.assertEqual(calls[0][2]['executionTime'], 1250)
        self.assertIn('/-/jobs/123/artifacts/raw/build/run/', calls[0][2]['comment'])
        self.assertNotIn('dummy', calls[0][2]['comment'])

    def test_executor_preserva_fail_e_continua(self):
        (self.root / 'flows').mkdir()
        flow = self.root / 'flows/pix.yaml'
        flow.write_text('appId: app\nproperties:\n  testCaseKey: PIX-T123\n---\n- launchApp\n')
        suite = self.root / 'suite.json'
        suite.write_text(json.dumps({'flows': ['flows/pix.yaml']}))
        def fake_run(cmd, **kwargs):
            output = Path(cmd[cmd.index('--output') + 1])
            output.write_text('<testsuite><testcase time="2"><failure message="Falha"/></testcase></testsuite>')
            artifacts = Path(cmd[cmd.index('--test-output-dir') + 1])
            artifacts.mkdir()
            (artifacts / 'video.mp4').write_text('fixture')
            (artifacts / 'falha.png').write_text('fixture')
            class Result:
                returncode = 1
            return Result()
        with patch.object(m.subprocess, 'run', side_effect=fake_run):
            manifest, failed = m.executar({}, suite, 'run-test')
        self.assertTrue(failed)
        item = json.loads(manifest.read_text())['results'][0]
        self.assertEqual(item['status'], 'FAIL')
        self.assertTrue(item['publishable'])
        self.assertEqual(len(item['evidence']), 3)

    def test_erro_publicacao_e_desabilitado(self):
        manifest = self.root / 'results.json'
        item = m.ler_junit(self.junit('<failure/>'), 'PIX-T123')
        item.update(publishable=True, evidence=[], warnings=[])
        manifest.write_text(json.dumps({'runId': 'run', 'results': [item]}))
        cfg = {'ZEPHYR_ENABLED': 'true', 'ZEPHYR_PROJECT_KEY': 'PIX', 'ZEPHYR_TEST_CYCLE_KEY': 'PIX-R1', 'ZEPHYR_TOKEN': 'dummy'}
        def fail(*args):
            raise RuntimeError('Zephyr HTTP 500')
        self.assertTrue(m.publicar(cfg, manifest, requester=fail))
        self.assertFalse(manifest.with_name('publication.json').exists())
        cfg['ZEPHYR_ENABLED'] = 'false'
        self.assertFalse(m.publicar(cfg, manifest, requester=fail))


if __name__ == '__main__':
    unittest.main()
